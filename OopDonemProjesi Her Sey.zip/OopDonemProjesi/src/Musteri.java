public class Musteri { // MUSTERIDEN KULLANICI ADINI ALMAK ICIN ...
	public static String kullaniciAdi;
	

	public Musteri() {
		
	}
	 
	public Musteri(String kullaniciAdi) {
		this.kullaniciAdi = kullaniciAdi;
		
	}
	public String getKullaniciAdi() {
		return kullaniciAdi;
	}
	public void setKullaniciAdi(String value) {
		this.kullaniciAdi = value;
	}
	
}

