public class Konut extends Emlak{ // EMLAKTAN EXTEND EDILMIS
	private int id;
	private String il;
	private String ilce;
	private int m2;
	private String oda_sayisi;
	private int balkon;
	private int fiyat;


	// KONUT OZELLIKLERINI PARAMETRE OLARAK ALAN CONSTRUCTOR
	public Konut(int id, String il, String ilce, int m2, String oda_sayisi, int balkon, int fiyat) {
		super();
		this.id = id;
		this.il = il;
		this.ilce = ilce;
		this.m2 = m2;
		this.oda_sayisi = oda_sayisi;
		this.balkon = balkon;
		this.fiyat = fiyat;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIl() {
		return il;
	}
	public void setIl(String il) {
		this.il = il;
	}
	public String getIlce() {
		return ilce;
	}
	public void setIlce(String ilce) {
		this.ilce = ilce;
	}
	public int getM2() {
		return m2;
	}
	public void setM2(int m2) {
		this.m2 = m2;
	}
	public String getOda_sayisi() {
		return oda_sayisi;
	}
	public void setOda_sayisi(String oda_sayisi) {
		this.oda_sayisi = oda_sayisi;
	}
	public int getBalkon() {
		return balkon;
	}
	public void setBalkon(int balkon) {
		this.balkon = balkon;
	}
	public int getFiyat() {
		return fiyat;
	}
	public void setFiyat(int fiyat) {
		this.fiyat = fiyat;
	}
	
	
	
	
	
}
