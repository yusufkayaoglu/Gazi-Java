import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;

public class EmlakVasitaEkrani extends JFrame {

	private JPanel contentPane;
    static  Musteri musteri = new Musteri();


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmlakVasitaEkrani frame = new EmlakVasitaEkrani(musteri);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	
	public EmlakVasitaEkrani(Musteri musteri) {   // EMLAKVASITA EKRANI LAYOUT KISMI
		setTitle("Emlak ve Vasita Secim Ekrani");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 715, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIlanlarYazisi = new JLabel("\u0130LANLAR");
		lblIlanlarYazisi.setForeground(Color.RED);
		lblIlanlarYazisi.setFont(new Font("Arial Black", Font.PLAIN, 25));
		lblIlanlarYazisi.setBounds(288, 136, 139, 40);
		contentPane.add(lblIlanlarYazisi);
		
		JLabel lblGirisMsj = new JLabel("Hoşgeldiniz sayın "+musteri.getKullaniciAdi());
		lblGirisMsj.setBackground(Color.WHITE);
		lblGirisMsj.setForeground(new Color(0, 100, 0));
		lblGirisMsj.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 25));
		lblGirisMsj.setBounds(36, 45, 493, 40);
		contentPane.add(lblGirisMsj);
		
		JButton btnCikis = new JButton("\u00C7\u0131k\u0131\u015F Yap");
		btnCikis.setForeground(Color.RED);
		btnCikis.setBackground(Color.LIGHT_GRAY);
		btnCikis.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		btnCikis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  // GIRIS EKRANINA DONMEK ICIN ACTION PERFORMED
				GirisEkrani girisekrani = new GirisEkrani();
				setVisible(false);
				girisekrani.setVisible(true);
			}
		});
		btnCikis.setBounds(528, 46, 139, 40);
		contentPane.add(btnCikis);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(53, 186, 595, 246);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblEmlakYazisi = new JLabel("EMLAK");
		lblEmlakYazisi.setBackground(new Color(100, 149, 237));
		lblEmlakYazisi.setForeground(new Color(0, 0, 0));
		lblEmlakYazisi.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblEmlakYazisi.setBounds(137, 49, 94, 36);
		panel.add(lblEmlakYazisi);
		
		JLabel lblVasitaYazisi = new JLabel("VAS\u0130TA");
		lblVasitaYazisi.setForeground(new Color(0, 0, 0));
		lblVasitaYazisi.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblVasitaYazisi.setBounds(388, 49, 94, 36);
		panel.add(lblVasitaYazisi);
		
		JButton btnOtomobil = new JButton("OTOMOB\u0130L");
		btnOtomobil.setForeground(new Color(30, 144, 255));
		btnOtomobil.setBackground(new Color(255, 255, 255));
		btnOtomobil.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnOtomobil.setBounds(366, 127, 137, 47);
		panel.add(btnOtomobil);
		
		JButton btnKonut = new JButton("KONUT");
		btnKonut.setForeground(new Color(30, 144, 255));
		btnKonut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // KONUTA BUTONU ACTION PERFORMED
				KonutEkrani konut_ekrani = new KonutEkrani(EmlakVasitaEkrani.this,true);
				setVisible(false);
				konut_ekrani.setVisible(true);
			}
		});
		btnKonut.setBackground(new Color(255, 255, 255));
		btnKonut.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnKonut.setBounds(106, 127, 137, 47);
		panel.add(btnKonut);
		btnOtomobil.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  // OTOMOBIL BUTONU ACTION PERFORMED
				OtomobilEkrani otomobil_ekrani = new OtomobilEkrani(EmlakVasitaEkrani.this,true);
				
				setVisible(false);
				otomobil_ekrani.setVisible(true);
				
				
			}
		});
	}
}

