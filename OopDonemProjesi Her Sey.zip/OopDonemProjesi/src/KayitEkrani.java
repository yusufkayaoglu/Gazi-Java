

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;

public class KayitEkrani extends JFrame {
	VasitaMusteriIslemleri islemler = new VasitaMusteriIslemleri();

	private JPanel contentPane;
	private JTextField txtRegister;
	private JPasswordField txtPassword;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KayitEkrani frame = new KayitEkrani();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public KayitEkrani() {  // KAYIT EKRANI LAYOUT KISMI
		setTitle("Kayıt Ekranı");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 715, 500);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblUsername = new JLabel("Kullan\u0131c\u0131 Ad\u0131");
		lblUsername.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUsername.setBounds(85, 186, 173, 44);
		contentPane.add(lblUsername);

		JLabel lblPassword = new JLabel("\u015Eifre");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPassword.setBounds(85, 240, 173, 41);
		contentPane.add(lblPassword);

		txtRegister = new JTextField();
		txtRegister.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtRegister.setBounds(282, 192, 245, 38);
		contentPane.add(txtRegister);
		txtRegister.setColumns(10);

		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPassword.setBounds(282, 246, 245, 38);
		contentPane.add(txtPassword);
		JLabel lblMsj = new JLabel("");
		lblMsj.setHorizontalAlignment(SwingConstants.CENTER);
		lblMsj.setFont(new Font("Tahoma", Font.ITALIC, 16));
		JButton btnRegister = new JButton("Kay\u0131t Ol");
		btnRegister.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRegister.setForeground(Color.RED);
		btnRegister.setBackground(Color.LIGHT_GRAY);

		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // KULLANICI VE ŞİFRE ACTİON PERFORMED
				String kullaniciAdi = txtRegister.getText();
				String sifre = new String(txtPassword.getPassword());


				if (!kullaniciAdi.isEmpty() && !sifre.isEmpty()) {
					boolean kayitBasarili = islemler.kayitOl(kullaniciAdi, sifre);

					if (kayitBasarili) { // KAYIT BAŞARILIYSA GİRİŞ EKRANI AÇILIYOR
						lblMsj.setText("Kayıt Başarılı");
						GirisEkrani girisEkran = new GirisEkrani();
						setVisible(false);
						girisEkran.setVisible(true);
					} else {
						lblMsj.setText("Kayıt Başarısız... Lütfen tekrar deneyin.");
					}
				} else {
					lblMsj.setText("Kullanıcı adı ve şifre boş olamaz. Lütfen tüm alanları doldurun.");
				}
			}
		});
		btnRegister.setBounds(285, 365, 157, 58);
		contentPane.add(btnRegister);

		JLabel lblMessage = new JLabel("Kay\u0131t Ekran\u0131");
		lblMessage.setForeground(new Color(50, 205, 50));
		lblMessage.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 30));
		lblMessage.setBounds(237, 67, 245, 68);
		contentPane.add(lblMessage);
		lblMsj.setForeground(Color.RED);
		lblMsj.setBounds(10, 306, 681, 43);
		contentPane.add(lblMsj);

		JLabel lbl_tik = new JLabel(new ImageIcon(getClass().getResource("tik2.jpg")));
		lbl_tik.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lbl_tik.setBounds(101, 51, 101, 100);
		contentPane.add(lbl_tik);

		JButton btnCikis = new JButton("\u00C7\u0131k\u0131\u015F Yap");
		btnCikis.setForeground(Color.RED);
		btnCikis.setBackground(Color.LIGHT_GRAY);
		btnCikis.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnCikis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  // ÇIKIŞ EKRANI ACTİON PERFORMED
				GirisEkrani girisEkrani = new GirisEkrani();
				setVisible(false);
				girisEkrani.setVisible(true);
			}
		});
		btnCikis.setBounds(507, 77, 157, 58);
		contentPane.add(btnCikis);
	}
}
