import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;
import java.awt.Color;
import java.awt.SystemColor;

public class GirisEkrani extends JFrame {
	VasitaMusteriIslemleri islemler = new VasitaMusteriIslemleri();
	private JPanel contentPane;
	private JTextField txtUserName;
	private JPasswordField txtPassword;
	private JButton btnRegister;
	private JLabel lblMsj;
	private JLabel lblKralindanaHGYazisi;
	private JLabel lbl_logo;
	private JLabel lblNewLabel_1;
	private JLabel lblTacResmi;
	public static String kullanici_adim;
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GirisEkrani frame = new GirisEkrani();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public GirisEkrani() {  // GİRİŞ EKRANI LAYOUT KODLARI
		setTitle("Giriş Ekranı");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 715, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUserName = new JLabel("Kullan\u0131c\u0131 Ad\u0131");
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblUserName.setBounds(150, 215, 123, 22);
		contentPane.add(lblUserName);
		
		txtUserName = new JTextField();
		txtUserName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUserName.setBounds(306, 213, 231, 34);
		contentPane.add(txtUserName);
		txtUserName.setColumns(10);
		
		JLabel lblPassword = new JLabel("\u015Eifre");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPassword.setBounds(150, 259, 94, 22);
		contentPane.add(lblPassword);
		
		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPassword.setBounds(306, 257, 231, 34);
		contentPane.add(txtPassword);
		
		JButton btnLogin = new JButton("Giri\u015F Yap");
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnLogin.setForeground(Color.RED);
		btnLogin.setBackground(Color.LIGHT_GRAY);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // GIRIS ISLEMLERI ACTİON PERFRORMED
				String Kullanici_adi = txtUserName.getText();
				String parola = new String(txtPassword.getPassword());
				boolean girisBasarili = islemler.girisYap(Kullanici_adi,parola);
				if(girisBasarili) {
					lblMsj.setText("Giriş Başarılı");
						Musteri musteri = new Musteri(Kullanici_adi);
						VasitaMusteriIslemleri musteriIslemleri = new VasitaMusteriIslemleri();
						VasitaMusteriIslemleri musteriIslemleri2 = new VasitaMusteriIslemleri(musteri);
						EmlakVasitaEkrani emlakvasita = new EmlakVasitaEkrani(musteri);
						emlakvasita.setVisible(true);
						setVisible(false);
				}
				else {
					lblMsj.setText("Giriş Başarısız...Lütfen tekrar deneyin.");
				}
				
			}
		});
		
		btnLogin.setBounds(424, 366, 153, 51);
		contentPane.add(btnLogin);
		
		btnRegister = new JButton("Kay\u0131t Ol");
		btnRegister.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRegister.setBackground(Color.LIGHT_GRAY);
		btnRegister.setForeground(Color.RED);
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // KAYIT OL BUTONU ACTION PERFORMED
				KayitEkrani kayitEkrani = new KayitEkrani();
				kayitEkrani.setVisible(true);
				setVisible(false);
		        
			}
		});
		btnRegister.setBounds(129, 366, 153, 51);
		contentPane.add(btnRegister);
		
		lblMsj = new JLabel("");
		lblMsj.setFont(new Font("Tahoma", Font.ITALIC, 18));
		lblMsj.setForeground(Color.RED);
		lblMsj.setBounds(129, 312, 507, 27);
		contentPane.add(lblMsj);
		
		lblKralindanaHGYazisi = new JLabel("KRALINDAN'A HO\u015EGELD\u0130N\u0130Z");
		lblKralindanaHGYazisi.setForeground(new Color(0, 0, 205));
		lblKralindanaHGYazisi.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 25));
		lblKralindanaHGYazisi.setBounds(150, 124, 417, 69);
		contentPane.add(lblKralindanaHGYazisi);
		
		lblTacResmi = new JLabel(new ImageIcon(getClass().getResource("tac2.jpg")));
		lblTacResmi.setBounds(281, 26, 142, 100);
		contentPane.add(lblTacResmi);
		
	
		
		
		
	}
}

