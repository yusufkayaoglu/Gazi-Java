public abstract class Emlak { // KONUT TEMEL OZELLIKLERI

	abstract int getId();
	abstract String getIl();
	abstract String getIlce();
	abstract int getM2();
	abstract String getOda_sayisi();
	abstract int getBalkon();
	abstract int getFiyat();
}
