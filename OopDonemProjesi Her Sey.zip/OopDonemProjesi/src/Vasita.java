public abstract class Vasita { // ARAC TEMEL OZELLIKLERI
	
	abstract int getId();
	abstract String getMarka();
	abstract String getModel() ;
	abstract int getYil() ;
	abstract String getPaket();
	abstract int getKm() ;
	abstract int getFiyat() ;
	
}

