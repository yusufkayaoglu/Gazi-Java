public class Otomobil extends Vasita { // VASITA DAN EXTEND EDILMIS
	private int id;
	private String marka;
	private String model;
	private int yil;
	private String paket;
	private int km;
	private int fiyat;

	// OTOMOBIL OZELLIKLERINI PARAMETRE OLARAK ALAN CONSTRUCTOR
	public Otomobil(int id, String marka, String model, int yil, String paket, int km, int fiyat) {
		super();
		this.id = id;
		this.marka = marka;
		this.model = model;
		this.yil = yil;
		this.paket = paket;
		this.km = km;
		this.fiyat = fiyat;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		this.marka = marka;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYil() {
		return yil;
	}
	public void setYil(int yil) {
		this.yil = yil;
	}
	public String getPaket() {
		return paket;
	}
	public void setPaket(String paket) {
		this.paket = paket;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	public int getFiyat() {
		return fiyat;
	}
	public void setFiyat(int fiyat) {
		this.fiyat = fiyat;
	}
	
}

