public class SelectOtomobil extends Vasita {  // BIR MUSTERIYE AIT OLAN OTOMOBILLER ICIN OLUSTURULAN SINIF

	private String musteri_ad;
	private int id;
	private String marka;
	private String model;
	private int yil;
	private String paket;
	private int km;
	private int fiyat;
	public SelectOtomobil(String musteri_ad,int id, String marka, String model, int yil, String paket, int km, int fiyat) {
		this.id = id;
		this.marka = marka;
		this.model = model;
		this.yil = yil;
		this.paket = paket;
		this.km = km;
		this.fiyat = fiyat;
		this.musteri_ad = musteri_ad;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMarka() {
		return marka;
	}
	public void setMarka(String marka) {
		this.marka = marka;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYil() {
		return yil;
	}
	public void setYil(int yil) {
		this.yil = yil;
	}
	public String getPaket() {
		return paket;
	}
	public void setPaket(String paket) {
		this.paket = paket;
	}
	public int getKm() {
		return km;
	}
	public void setKm(int km) {
		this.km = km;
	}
	public int getFiyat() {
		return fiyat;
	}
	public void setFiyat(int fiyat) {
		this.fiyat = fiyat;
	}
	
	public String getMusteri_ad() {
		return musteri_ad;
	}
	public void setMusteri_ad(String musteri_ad) {
		this.musteri_ad = musteri_ad;
	}
	
	
	

}

