import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class EmlakMusteriIslemleri implements IMusteriIslemleri {

    // BU SINIFIN KURULMA AMACI GENEL OLARAK KONUT ILANLARINA AIT VERITABANI ISLEMLERINI YONETMEK


    // VERITABANI BAGLANTI ISLEMLERI
	private Statement statement = null;
	private Connection con  = null;
	private PreparedStatement preparedStatement = null;
	Musteri musteri = new Musteri();
	
	
    public EmlakMusteriIslemleri(Musteri musteri) {
		super();
	}


    // VERITABANDA ILAN GUNCELLEMEK ICIN KULLANILAN FONKSIYON
    public void ilanlarimiGuncelle(int id,String musteri_ad_yeni, String il_yeni, String ilce_yeni, int m2_yeni, String oda_sayisi_yeni, int balkon_yeni, int fiyat_yeni) {
    	String sorgu = "Update selected_emlak set il = ? , ilce = ? , m2 = ? , oda_sayisi = ? , balkon = ? , fiyat = ? where id = ?  ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
            preparedStatement.setString(1, il_yeni);
            preparedStatement.setString(2, ilce_yeni );
            preparedStatement.setInt(3, m2_yeni);
            preparedStatement.setString(4, oda_sayisi_yeni);
            preparedStatement.setInt(5, balkon_yeni);
            preparedStatement.setInt(6, fiyat_yeni);
            preparedStatement.setInt(7,id);
            preparedStatement.executeUpdate();
            
            

		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	
    }


    // VERITABANDA ILAN GUNCELLEMEK ICIN KULLANILAN FONKSIYON  (TUM ILANLAR ICIN)
    public void tumilanlarimiGuncelle(int id,String musteri_ad_yeni, String il_yeni, String ilce_yeni, int m2_yeni, String oda_sayisi_yeni, int balkon_yeni, int fiyat_yeni) {
    	String sorgu = "Update emlak set il = ? , ilce = ? , m2 = ? , oda_sayisi = ? , balkon = ? , fiyat = ? where id = ?  ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
            preparedStatement.setString(1, il_yeni);
            preparedStatement.setString(2, ilce_yeni );
            preparedStatement.setInt(3, m2_yeni);
            preparedStatement.setString(4, oda_sayisi_yeni);
            preparedStatement.setInt(5, balkon_yeni);
            preparedStatement.setInt(6, fiyat_yeni);
            preparedStatement.setInt(7,id);
            preparedStatement.executeUpdate();
            

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }

    // VERITABANDAN ILAN SILMEK ICIN KULLANILAN FONKSIYON
    public void ilanlarimiSil(int id) {
    	String sorgu = "Delete from selected_emlak where id = ? ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
			preparedStatement.setInt(1,id);
			preparedStatement.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }

    // VERITABANDAN ILAN SILMEK ICIN KULLANILAN FONKSIYON  (TUM ILANLAR ICIN)
    public void tumilanlarimiSil(int id) {
    	String sorgu = "Delete from emlak where id = ? ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
			preparedStatement.setInt(1,id);
			preparedStatement.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }


    // VERITABANINDAKI KONUT TABLOSUNDAKI VERILERI GORMEK ICIN OLUSTURULAN ARRAYLIST
	public ArrayList<Konut> tumEmlakIlanlarimiGetir() {
        
        ArrayList<Konut> cikti3 = new ArrayList<Konut>();
        
        try {
            statement =  con.createStatement();
            String sorgu =  "Select * From emlak";
            
            ResultSet rs =  statement.executeQuery(sorgu);
            
            while(rs.next()) {
                int id = rs.getInt("id");
                String il = rs.getString("il");
                String ilce = rs.getString("ilce");
                int m2  = rs.getInt("m2");
                String oda_sayisi = rs.getString("oda_sayisi");
                int balkon = rs.getInt("balkon");
                int fiyat = rs.getInt("fiyat");
                
                
                cikti3.add(new Konut(id,il,ilce,m2,oda_sayisi,balkon,fiyat));
                
                
            }
            return cikti3;
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
            return null;
            
        }
      
    }



    // VERITABANINA ILAN EKLEMEK ICIN KULLANILAN FONKSIYON
    public void ilanlarimaEkle( String musteri_ad, String il, String ilce, int m2, String oda_sayisi, int balkon,int fiyat) {
        String sorgu = "INSERT INTO selected_emlak (musteri_ad, il, ilce, m2, oda_sayisi, balkon, fiyat) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = con.prepareStatement(sorgu, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, musteri_ad);
            preparedStatement.setString(2, il);
            preparedStatement.setString(3, ilce);
            preparedStatement.setInt(4, m2);
            preparedStatement.setString(5, oda_sayisi);
            preparedStatement.setInt(6, balkon);
            preparedStatement.setInt(7, fiyat);

            // ilan eklemeyi gerceklestir
            preparedStatement.executeUpdate();

            // Eklenen ilanin ID'sini al
            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int eklenenIlaninIDsi = generatedKeys.getInt(1);
                    System.out.println("Eklenen ilanın ID'si: " + eklenenIlaninIDsi);

                    // Simdi bu ID'yi kullanabilirsiniz
                    tumilanEkle(eklenenIlaninIDsi, il, ilce, m2, oda_sayisi, balkon, fiyat);
                } else {
                    throw new SQLException("ID alınamadı, kayıt eklenemedi.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // VERITABANINA ILAN EKLEMEK ICIN KULLANILAN FONKSIYON  (TUM ILANLAR ICIN)
    public void tumilanEkle(int id,String il,String ilce,int m2,String oda_sayisi,int balkon,int fiyat) {
    	String sorgu = "Insert Into emlak(id,il,ilce,m2,oda_sayisi,balkon,fiyat) VALUES (?,?,?,?,?,?,?)";
    	
    	try {

            preparedStatement = con.prepareStatement(sorgu);
            preparedStatement.setInt(1, id);  // ID degeri ataniyor
            preparedStatement.setString(2, il);
            preparedStatement.setString(3, ilce);
            preparedStatement.setInt(4, m2);
            preparedStatement.setString(5, oda_sayisi);
            preparedStatement.setInt(6, balkon);
            preparedStatement.setInt(7, fiyat);
           
			

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }



    // VERITABANINA DIREKT BAGLANMAK ICIN OLUSTURULAN CONSTRUCTOR
	public EmlakMusteriIslemleri() {
        
		String url = "jdbc:mysql://"+Database.host+":"+Database.port+"/"+Database.db_ismi+"?useUnicode=true&characterEncoding=utf8";
		try{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException ex) {
			System.out.println("Driver bulunamadı...");
		}
		
		try {
			con =  DriverManager.getConnection(url,Database.kullanıcı_adı,Database.parola);
			System.out.println("Bağlantı başarılı...");
		} catch (SQLException ex) {
			System.out.println("Bağlantı basarısız..");
			ex.printStackTrace();
		}
	}


    // BELIRLI BIR MUSTERININ ILANLARINI GETIRMEK ICIN OLUSTURULAN FONKSIYON
    public ArrayList<SelectKonut> ilanlarimiGetir() {
        
        ArrayList<SelectKonut> cikti5 = new ArrayList<SelectKonut>();
        
        try {

        	preparedStatement = con.prepareStatement("SELECT * FROM selected_emlak WHERE musteri_ad = ?");
        	String ad = musteri.getKullaniciAdi();
        	preparedStatement.setString(1, ad);
        	ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()) {
            	String musteri_ad = rs.getString("musteri_ad");
                int id = rs.getInt("id");
                String il = rs.getString("il");
                String ilce = rs.getString("ilce");
                int m2  = rs.getInt("m2");
                String oda_sayisi = rs.getString("oda_sayisi");
                int balkon = rs.getInt("balkon");
                int fiyat = rs.getInt("fiyat");
           
                cikti5.add(new SelectKonut(id,musteri_ad, il,ilce,m2, oda_sayisi,balkon,fiyat));
                
                
            }
            return cikti5;
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
            return null;
            
        }
        
    } 

    // MUSTERININ ILAN SAYISINI GETIRMEK ICIN OLUSTURULAN FONKSIYON
    public String musteriIlanSayisiniGetir(String musteri_ad) {
        int sayi = 0;
        String strSayi="";
        try {
            preparedStatement = con.prepareStatement("SELECT COUNT(*) as ilan_sayisi FROM selected_emlak WHERE musteri_ad = ?");
            preparedStatement.setString(1, musteri_ad);
            ResultSet rs = preparedStatement.executeQuery();
            
            if (rs.next()) {
            	sayi= rs.getInt("ilan_sayisi");
            	strSayi = Integer.toString(sayi);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return strSayi;
    }

    // TUM ILANLARIN SAYISINI GETIRMEK ICIN OLUSTURULAN FONKSIYON
    public String toplamIlanSayisiniGetir() {
        int sayi = 0;
        String strSayi = "";
        try {
            preparedStatement = con.prepareStatement("SELECT COUNT(*) as ilan_sayisi FROM emlak");
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                sayi = rs.getInt("ilan_sayisi");
                strSayi = Integer.toString(sayi);
            }

        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
        }

        return strSayi;
    }


    

	public static void main(String[] args) {
		EmlakMusteriIslemleri islemler = new EmlakMusteriIslemleri();
		
	
	}
	
	 
	 
 }
	
	
	
	
	


