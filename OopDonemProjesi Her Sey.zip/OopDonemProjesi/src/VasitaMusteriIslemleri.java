import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class VasitaMusteriIslemleri implements IMusteriIslemleri {

    // BU SINIFIN KURULMA AMACI GENEL OLARAK KONUT ILANLARINA AIT VERITABANI ISLEMLERINI YONETMEK


    // VERITABANI BAGLANTI ISLEMLERI
	private Statement statement = null;
	private Connection con  = null;
	private PreparedStatement preparedStatement = null;
	Musteri musteri = new Musteri();
	
	
    public VasitaMusteriIslemleri(Musteri musteri) {
		super();
	}


    // VERITABANDA ILAN GUNCELLEMEK ICIN KULLANILAN FONKSIYON
    public void ilanlarimiGuncelle(int id,String musteri_ad_yeni, String marka_yeni, String model_yeni, int yil_yeni, String paket_yeni, int km_yeni, int fiyat_yeni) {
    	String sorgu = "Update selected_car set marka = ? , model = ? , yil = ? , paket = ? , km = ? , fiyat = ? where id = ?  ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
            preparedStatement.setString(1, marka_yeni);
            preparedStatement.setString(2, model_yeni );
            preparedStatement.setInt(3, yil_yeni);
            preparedStatement.setString(4, paket_yeni);
            preparedStatement.setInt(5, km_yeni);
            preparedStatement.setInt(6, fiyat_yeni);
            preparedStatement.setInt(7,id);
            preparedStatement.executeUpdate();
           
            

		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	
    }


    // VERITABANDA ILAN GUNCELLEMEK ICIN KULLANILAN FONKSIYON  (TUM ILANLAR ICIN)
    public void tumilanlarimiGuncelle(int id,String musteri_ad_yeni, String marka_yeni, String model_yeni, int yil_yeni, String paket_yeni, int km_yeni, int fiyat_yeni) {
    	String sorgu = "Update car set marka = ? , model = ? , yil = ? , paket = ? , km = ? , fiyat = ? where id = ?  ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
            preparedStatement.setString(1, marka_yeni);
            preparedStatement.setString(2, model_yeni );
            preparedStatement.setInt(3, yil_yeni);
            preparedStatement.setString(4, paket_yeni);
            preparedStatement.setInt(5, km_yeni);
            preparedStatement.setInt(6, fiyat_yeni);
            preparedStatement.setInt(7,id);
            preparedStatement.executeUpdate();
            

		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    }

    // VERITABANDAN ILAN SILMEK ICIN KULLANILAN FONKSIYON
    public void ilanlarimiSil(int id) {
    	String sorgu = "Delete from selected_car where id = ? ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
			preparedStatement.setInt(1,id);
			preparedStatement.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }


    // VERITABANDAN ILAN SILMEK ICIN KULLANILAN FONKSIYON  (TUM ILANLAR ICIN)
    public void tumilanlarimiSil(int id) {
    	String sorgu = "Delete from car where id = ? ";
    	try {
			preparedStatement = con.prepareStatement(sorgu);
			preparedStatement.setInt(1,id);
			preparedStatement.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }


    // VERITABANINDAKI OTOMOBIL TABLOSUNDAKI VERILERI GORMEK ICIN OLUSTURULAN ARRAYLIST
	public ArrayList<Otomobil> tumIlanlarimiGetir() {
        
        ArrayList<Otomobil> cikti = new ArrayList<Otomobil>();
        
        try {
            statement =  con.createStatement();
            String sorgu =  "Select * From car";
            
            ResultSet rs =  statement.executeQuery(sorgu);
            
            while(rs.next()) {
                int id = rs.getInt("id");
                String marka = rs.getString("marka");
                String model = rs.getString("model");
                int yil  = rs.getInt("yil");
                String paket = rs.getString("paket");
                int km = rs.getInt("km");
                int fiyat = rs.getInt("fiyat");
                
                
                cikti.add(new Otomobil(id, marka,model,yil, paket,km,fiyat));
                
                
            }
            return cikti;
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
            return null;
            
        }
      
    }

    // VERITABANINA ILAN EKLEMEK ICIN KULLANILAN FONKSIYON  (TUM ILANLAR ICIN)
    public void tumilanEkle(int id,String marka,String model,int yil,String paket,int km,int fiyat) { 
    	String sorgu = "Insert Into car(id,marka,model,yil,paket,km,fiyat) VALUES (?,?,?,?,?,?,?)";
    	
    	try {

            preparedStatement = con.prepareStatement(sorgu);
            preparedStatement.setInt(1, id); 
            preparedStatement.setString(2, marka);
            preparedStatement.setString(3, model);
            preparedStatement.setInt(4, yil);
            preparedStatement.setString(5, paket);
            preparedStatement.setInt(6, km);
            preparedStatement.setInt(7, fiyat);
           
			

			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }



    // VERITABANINA ILAN EKLEMEK ICIN KULLANILAN FONKSIYON
    public void ilanlarimaEkle(String musteri_ad, String marka, String model, int yil, String paket, int km, int fiyat) {
        String sorgu = "INSERT INTO selected_car (musteri_ad, marka, model, yil, paket, km, fiyat) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = con.prepareStatement(sorgu, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, musteri_ad);
            preparedStatement.setString(2, marka);
            preparedStatement.setString(3, model);
            preparedStatement.setInt(4, yil);
            preparedStatement.setString(5, paket);
            preparedStatement.setInt(6, km);
            preparedStatement.setInt(7, fiyat);

            // ilan eklemeyi gerceklestir
            preparedStatement.executeUpdate();

            // Eklenen ilanin ID'sini al
            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int eklenenIlaninIDsi = generatedKeys.getInt(1);
                    System.out.println("Eklenen ilanın ID'si: " + eklenenIlaninIDsi);

                    // simdi bu ID'yi kullanabilirsiniz
                    tumilanEkle(eklenenIlaninIDsi, marka, model, yil, paket, km, fiyat);
                } else {
                    throw new SQLException("ID alınamadı, kayıt eklenemedi.");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // GIRIS ISLEMLERI (VERITABANI)
	public boolean girisYap(String kullanici_adi,String parola) {
		String sorgu = "Select * from müsteri  where kullanıcı_adı = ? and sifre = ?";
		try {
			preparedStatement = con.prepareStatement(sorgu);
			preparedStatement.setString(1,kullanici_adi);
			preparedStatement.setString(2, parola);
			ResultSet rs = preparedStatement.executeQuery();
			return rs.next();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			return false;
		}
	}


    // KAYIT ISLEMLERI (VERITABANI)
    public boolean kayitOl(String kullaniciAdi, String sifre) {
        // Kullanici adinin mevcut olup olmadigini kontrol et
        String kontrolSorgu = "SELECT * FROM müsteri  WHERE kullanıcı_adı = ?";
        try {
            preparedStatement = con.prepareStatement(kontrolSorgu);
            preparedStatement.setString(1, kullaniciAdi);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                // Kullanici adi zaten mevcut
                System.out.println("Kullanıcı adı zaten mevcut.");
                return false;
            } else {
                // Kullanici adi mevcut degil, yeni kayit yap
                String kayitSorgu = "INSERT INTO müsteri (kullanıcı_adı, sifre) VALUES (?, ?)";
                preparedStatement = con.prepareStatement(kayitSorgu);
                preparedStatement.setString(1, kullaniciAdi);
                preparedStatement.setString(2, sifre);
                int etkilenenSatir = preparedStatement.executeUpdate();

                if (etkilenenSatir > 0) {
                    System.out.println("Kayıt başarılı.");
                    return true;
                } else {
                    System.out.println("Kayıt başarısız.");
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // VERITABANINA DIREKT BAGLANMAK ICIN OLUSTURULAN CONSTRUCTOR
	public VasitaMusteriIslemleri() {
        
		String url = "jdbc:mysql://"+Database.host+":"+Database.port+"/"+Database.db_ismi+"?useUnicode=true&characterEncoding=utf8";
		try{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(ClassNotFoundException ex) {
			System.out.println("Driver bulunamadı...");
		}
		
		try {
			con =  DriverManager.getConnection(url,Database.kullanıcı_adı,Database.parola);
			System.out.println("Bağlantı başarılı...");
		} catch (SQLException ex) {
			System.out.println("Bağlantı başarısız..");
			ex.printStackTrace();
		}
	}



    // BELIRLI BIR MUSTERININ ILANLARINI GETIRMEK ICIN OLUSTURULAN FONKSIYON
    public ArrayList<SelectOtomobil> ilanlarimiGetir() { //Bu fonksiyon belirli bir musterinin ilanlarini getirmek icin
        
        ArrayList<SelectOtomobil> cikti2 = new ArrayList<SelectOtomobil>();
        
        try {

        	preparedStatement = con.prepareStatement("SELECT * FROM selected_car WHERE musteri_ad = ?");
        	String ad = musteri.getKullaniciAdi();
        	preparedStatement.setString(1, ad);
        	ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()) {
            	String musteri_ad = rs.getString("musteri_ad");
                int id = rs.getInt("id");
                String marka = rs.getString("marka");
                String model = rs.getString("model");
                int yil  = rs.getInt("yil");
                String paket = rs.getString("paket");
                int km = rs.getInt("km");
                int fiyat = rs.getInt("fiyat");
                
                
                cikti2.add(new SelectOtomobil(musteri_ad,id, marka,model,yil, paket,km,fiyat));
                
                
            }
            return cikti2;
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
            return null;
            
        }
        
    }


    // MUSTERININ ILAN SAYISINI GETIRMEK ICIN OLUSTURULAN FONKSIYON
    public String musteriIlanSayisiniGetir(String musteri_ad) {
        int sayi = 0;
        String strSayi="";
        try {
            preparedStatement = con.prepareStatement("SELECT COUNT(*) as ilan_sayisi FROM selected_car WHERE musteri_ad = ?");
            preparedStatement.setString(1, musteri_ad);
            ResultSet rs = preparedStatement.executeQuery();
            
            if (rs.next()) {
            	sayi= rs.getInt("ilan_sayisi");
            	strSayi = Integer.toString(sayi);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return strSayi;
    }

    // TUM ILANLARIN SAYISINI GETIRMEK ICIN OLUSTURULAN FONKSIYON
    public String toplamIlanSayisiniGetir() {
        int sayi = 0;
        String strSayi = "";
        try {
            preparedStatement = con.prepareStatement("SELECT COUNT(*) as ilan_sayisi FROM car");
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                sayi = rs.getInt("ilan_sayisi");
                strSayi = Integer.toString(sayi);
            }

        } catch (SQLException ex) {
            Logger.getLogger(VasitaMusteriIslemleri.class.getName()).log(Level.SEVERE, null, ex);
        }

        return strSayi;
    }
    

	public static void main(String[] args) {
		VasitaMusteriIslemleri islemler = new VasitaMusteriIslemleri();
		
	} 
 }



