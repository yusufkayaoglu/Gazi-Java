import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;


public class OtomobilIlanlarimEkrani extends javax.swing.JDialog {
    DefaultTableModel model;
    VasitaMusteriIslemleri islemler =  new VasitaMusteriIslemleri();
    Musteri musteri = new Musteri();
    
   
    
    
    
    
    public OtomobilIlanlarimEkrani(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        getContentPane().setBackground(Color.WHITE);
        initComponents();
        model = (DefaultTableModel) ilanlarim_tablosu.getModel();
        musteriotomobilGoruntule();

        
    }

    
	@SuppressWarnings("unchecked")
 
    private void initComponents() {  // OTOMOBIL ILANLARIM TABLOSU

        jScrollPane1 = new javax.swing.JScrollPane();
        ilanlarim_tablosu = new javax.swing.JTable();
        ilanlarim_tablosu.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int selectedrow = ilanlarim_tablosu.getSelectedRow();
                txtMarka.setText(model.getValueAt(selectedrow, 2).toString());
                txtModel.setText(model.getValueAt(selectedrow, 3).toString());
                txtYil.setText(model.getValueAt(selectedrow, 4).toString());
                txtPaket.setText(model.getValueAt(selectedrow, 5).toString());
                txtKm.setText(model.getValueAt(selectedrow, 6).toString());
                txtFiyat.setText(model.getValueAt(selectedrow, 7).toString());
                
               
        	}
        });

        
        

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        ilanlarim_tablosu.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id","musteri_ad", "marka", "model", "yil", "paket","km","fiyat"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false,false,false,false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
       
        jScrollPane1.setViewportView(ilanlarim_tablosu);
        if (ilanlarim_tablosu.getColumnModel().getColumnCount() > 0) {
            ilanlarim_tablosu.getColumnModel().getColumn(0).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(1).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(2).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(3).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(4).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(5).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(6).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(7).setResizable(false);
        }

        
        JLabel lblMarka = new JLabel("Marka");
        lblMarka.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblModel = new JLabel("Model");
        lblModel.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblYil = new JLabel("Y\u0131l");
        lblYil.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblPaket = new JLabel("Paket");
        lblPaket.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblKm = new JLabel("Km");
        lblKm.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblFiyat = new JLabel("Fiyat");
        lblFiyat.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        txtMarka = new JTextField();
        txtMarka.setColumns(10);
        
        txtModel = new JTextField();
        txtModel.setColumns(10);
        
        txtYil = new JTextField();
        txtYil.setColumns(10);
        
        txtPaket = new JTextField();
        txtPaket.setColumns(10);
        
        txtKm = new JTextField();
        txtKm.setColumns(10);
        
        txtFiyat = new JTextField();
        txtFiyat.setColumns(10);

        

        
        lblIlanSayi = new JLabel();
        lblIlanSayi.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        JLabel lblMsj = new JLabel("");
        lblMsj.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
        lblMsj.setForeground(Color.RED);
       
        JButton btnGeri = new JButton("Geri");
        btnGeri.setBackground(Color.LIGHT_GRAY);
        btnGeri.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnGeri.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // GERI BUTONU ACTION PERFORMED
        	
        		OtomobilEkrani otomobil = new OtomobilEkrani(new JFrame(), true);
        		setVisible(false);
        		otomobil.setVisible(true);
        		
        	}
        });
        
      
        JButton btnIlanEkle = new JButton("\u0130lan Ekle");
        btnIlanEkle.setBackground(Color.LIGHT_GRAY);
        btnIlanEkle.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnIlanEkle.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // ILAN EKLE BUTONU ACTION PERFORMED
        		lblMsj.setText("");
        		String musteri_ad = Musteri.kullaniciAdi;
        		String marka = txtMarka.getText();
        		String model = txtModel.getText();
        		int yil =Integer.parseInt(txtYil.getText());
        		String paket = txtPaket.getText();
        		int km = Integer.parseInt(txtKm.getText());
        		int fiyat = Integer.parseInt(txtFiyat.getText());
        		islemler.ilanlarimaEkle(musteri_ad,marka,model,yil,paket,km,fiyat);
        		musteriotomobilGoruntule();
        		lblMsj.setText("Yeni ilan başarıyla eklendi");

        		
        	}
        });
        btnGuncelle = new JButton("\u0130lan G\u00FCncelle");
        btnGuncelle.setBackground(Color.LIGHT_GRAY);
        btnGuncelle.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnGuncelle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {  // ILAN GUNCELLE BUTONU ACTION PERFORMED
                String marka = txtMarka.getText();
                String modeli = txtModel.getText();
                int yil = Integer.parseInt(txtYil.getText());
                String paket = txtPaket.getText();
                int km = Integer.parseInt(txtKm.getText());
                int fiyat = Integer.parseInt(txtFiyat.getText());
                int selectedrow = ilanlarim_tablosu.getSelectedRow();

         
                if (selectedrow == -1) {
                    if (model.getRowCount() == 0) {
                        lblMsj.setText("İlanlar tablosu şu anda boş.");
                    } else {
                        lblMsj.setText("Lütfen güncellenecek bir ilan seçin.");
                    }
                } else {
                	int id =(int)model.getValueAt(selectedrow, 0);
                	islemler.ilanlarimiGuncelle(id,Musteri.kullaniciAdi,marka,modeli,yil,paket,km,fiyat);
                	islemler.tumilanlarimiGuncelle(id, Musteri.kullaniciAdi, marka, modeli, yil, paket, km, fiyat);
                	musteriotomobilGoruntule();
            		lblMsj.setText("İlan başarıyla güncellendi.");

                	
                }
            }
        });
        btnSil = new JButton("\u0130lan Sil");
        btnSil.setBackground(Color.LIGHT_GRAY);
        btnSil.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnSil.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // ILAN SIL BUTONU ACTION PERFORMED
        	    lblMsj.setText("");
        		int selectedrow = ilanlarim_tablosu.getSelectedRow();
        		if (selectedrow == -1) {
                    if (model.getRowCount() == 0) {
                        lblMsj.setText("İlanlar tablosu şu anda boş.");
                    } else {
                        lblMsj.setText("Lütfen silinecek bir ilan seçin.");
                    }
                } else {
                	int id =(int)model.getValueAt(selectedrow, 0);
                	islemler.ilanlarimiSil(id);
                	islemler.tumilanlarimiSil(id);
                	musteriotomobilGoruntule();
            		lblMsj.setText("İlan başarıyla silindi.");

                }
        	}
        });




        // GENEL LAYOUT
    
        GroupLayout layout = new GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(25)
        					.addGroup(layout.createParallelGroup(Alignment.LEADING)
        						.addGroup(layout.createSequentialGroup()
        							.addComponent(lblFiyat, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.RELATED))
        						.addGroup(layout.createParallelGroup(Alignment.LEADING)
        							.addGroup(layout.createSequentialGroup()
        								.addComponent(lblMarka)
        								.addPreferredGap(ComponentPlacement.RELATED))
        							.addGroup(layout.createParallelGroup(Alignment.LEADING)
        								.addGroup(layout.createSequentialGroup()
        									.addComponent(lblYil)
        									.addPreferredGap(ComponentPlacement.RELATED))
        								.addGroup(layout.createSequentialGroup()
        									.addGroup(layout.createParallelGroup(Alignment.LEADING)
        										.addComponent(lblPaket, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
        										.addComponent(lblKm, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE))
        									.addPreferredGap(ComponentPlacement.RELATED))
        								.addGroup(layout.createSequentialGroup()
        									.addComponent(lblModel)
        									.addGap(31)))))
        					.addGroup(layout.createParallelGroup(Alignment.LEADING)
        						.addGroup(layout.createSequentialGroup()
        							.addGroup(layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(txtModel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        								.addComponent(txtYil, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        								.addComponent(txtMarka, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        								.addComponent(txtPaket, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        								.addComponent(txtKm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        							.addGap(383)
        							.addGroup(layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(btnGuncelle, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        								.addComponent(btnSil, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        								.addComponent(btnIlanEkle, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        								.addComponent(btnGeri, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        								.addComponent(lblIlanSayi, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE))
        							.addGap(106))
        						.addGroup(layout.createSequentialGroup()
        							.addComponent(txtFiyat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        							.addContainerGap())))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
        					.addContainerGap())
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(lblMsj, GroupLayout.PREFERRED_SIZE, 475, GroupLayout.PREFERRED_SIZE)
        					.addGap(360))))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(43)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(btnIlanEkle)
        					.addGap(20))
        				.addGroup(layout.createSequentialGroup()
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblMarka, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtMarka, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.UNRELATED)))
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(btnGuncelle)
        				.addComponent(txtModel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblModel, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(18)
        					.addComponent(btnSil)
        					.addGap(18)
        					.addComponent(btnGeri))
        				.addGroup(layout.createSequentialGroup()
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblYil, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtYil, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(txtPaket, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblPaket, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblKm, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtKm, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblFiyat, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtFiyat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(12)
        					.addComponent(lblIlanSayi))
        				.addGroup(layout.createSequentialGroup()
        					.addGap(26)
        					.addComponent(lblMsj, GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 303, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        );
        getContentPane().setLayout(layout);

        pack();
    }

    public void musteriotomobilGoruntule() {   //  SADECE BELIRLI MUSTERILERIN ILANLARINI GETIRMEK ICIN OLUSTURULAN FONKSIYON VE ARRAYLIST
        
        model.setRowCount(0);
        
        ArrayList<SelectOtomobil> otomobil = new ArrayList<SelectOtomobil>();
        
        islemler.musteriIlanSayisiniGetir(musteri.getKullaniciAdi());
        
        lblIlanSayi.setText("Toplam İlan Sayısı: "+islemler.musteriIlanSayisiniGetir(musteri.getKullaniciAdi()));
        otomobil = islemler.ilanlarimiGetir();
       
        if (otomobil != null ) {
            
            for (SelectOtomobil car : otomobil) {
            	
                Object[] eklenecek = {car.getId(),car.getMusteri_ad(),car.getMarka(),car.getModel(),car.getYil(),car.getPaket(),car.getKm(),car.getFiyat()};
                
                model.addRow(eklenecek);
                
                
                
            }
            
        }
        
        
    }
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            	OtomobilIlanlarimEkrani dialog = new OtomobilIlanlarimEkrani(new JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    private javax.swing.JTable ilanlarim_tablosu;
    private javax.swing.JScrollPane jScrollPane1;
    private JTextField txtMarka;
    private JTextField txtModel;
    private JTextField txtYil;
    private JTextField txtPaket;
    private JTextField txtKm;
    private JTextField txtFiyat;
    private JButton btnGuncelle;
    private JButton btnSil;
    private JLabel lblIlanSayi;
}


