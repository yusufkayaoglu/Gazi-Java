import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;


public class KonutIlanlarimEkrani extends javax.swing.JDialog {
    DefaultTableModel model;
    EmlakMusteriIslemleri islemler =  new EmlakMusteriIslemleri();
    Musteri musteri = new Musteri();
    
   

    public KonutIlanlarimEkrani(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        getContentPane().setBackground(Color.WHITE);
        initComponents();
        model = (DefaultTableModel) ilanlarim_tablosu.getModel();
        musterikonutGoruntule();

        
    }


    private void initComponents() {  // KONUTILANLARIM TABLOSU

        jScrollPane1 = new javax.swing.JScrollPane();
        ilanlarim_tablosu = new javax.swing.JTable();
        ilanlarim_tablosu.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int selectedrow = ilanlarim_tablosu.getSelectedRow();
                txtIl.setText(model.getValueAt(selectedrow, 2).toString());
                txtIlce.setText(model.getValueAt(selectedrow, 3).toString());
                txtM2.setText(model.getValueAt(selectedrow, 4).toString());
                txtOdaSayisi.setText(model.getValueAt(selectedrow, 5).toString());
                txtBalkon.setText(model.getValueAt(selectedrow, 6).toString());
                txtFiyat.setText(model.getValueAt(selectedrow, 7).toString());
                
               
        	}
        });

        
        

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        ilanlarim_tablosu.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id","musteri_ad", "il", "ilce", "m2", "oda_sayisi","balkon","fiyat"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false,false,false,false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
       
        jScrollPane1.setViewportView(ilanlarim_tablosu);
        if (ilanlarim_tablosu.getColumnModel().getColumnCount() > 0) {
            ilanlarim_tablosu.getColumnModel().getColumn(0).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(1).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(2).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(3).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(4).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(5).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(6).setResizable(false);
            ilanlarim_tablosu.getColumnModel().getColumn(7).setResizable(false);
        }

        
        JLabel lblIl = new JLabel("\u0130l");
        lblIl.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblIlce = new JLabel("\u0130l\u00E7e");
        lblIlce.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblM2 = new JLabel("M2");
        lblM2.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblOdaSayisi = new JLabel("Oda Say\u0131s\u0131");
        lblOdaSayisi.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblBalkon = new JLabel("Balkon");
        lblBalkon.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        JLabel lblFiyat = new JLabel("Fiyat");
        lblFiyat.setFont(new Font("Tahoma", Font.BOLD, 12));
        
        txtIl = new JTextField();
        txtIl.setColumns(10);
        
        txtIlce = new JTextField();
        txtIlce.setColumns(10);
        
        txtM2 = new JTextField();
        txtM2.setColumns(10);
        
        txtOdaSayisi = new JTextField();
        txtOdaSayisi.setColumns(10);
        
        txtBalkon = new JTextField();
        txtBalkon.setColumns(10);
        
        txtFiyat = new JTextField();
        txtFiyat.setColumns(10);

        
        lblIlanSayi = new JLabel();
        lblIlanSayi.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        JLabel lblMsj = new JLabel("");
        lblMsj.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
        lblMsj.setForeground(Color.RED);
       
        JButton btnGeri = new JButton("Geri");
        btnGeri.setBackground(Color.LIGHT_GRAY);
        btnGeri.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnGeri.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // GERI BUTONU ACTION PERFORMED
        	
        		KonutEkrani konut = new KonutEkrani(new JFrame(), true);
        		setVisible(false);
        		konut.setVisible(true);
        		
        	}
        });
        
      
        JButton btnIlanEkle = new JButton("\u0130lan Ekle");
        btnIlanEkle.setBackground(Color.LIGHT_GRAY);
        btnIlanEkle.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnIlanEkle.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // ILAN EKLE BUTONU ACTION PERFORMED
        		lblMsj.setText("");
        		String musteri_ad = Musteri.kullaniciAdi;
        		String il = txtIl.getText();
        		String ilce = txtIlce.getText();
        		int m2 =Integer.parseInt(txtM2.getText());
        		String oda_sayisi = txtOdaSayisi.getText();
        		int balkon = Integer.parseInt(txtBalkon.getText());
        		int fiyat = Integer.parseInt(txtFiyat.getText());
        		islemler.ilanlarimaEkle(musteri_ad,il,ilce,m2,oda_sayisi,balkon,fiyat);
        		musterikonutGoruntule();
        		lblMsj.setText("Yeni ilan başarıyla eklendi");

        		
        	}
        });
        btnGuncelle = new JButton("\u0130lan G\u00FCncelle");
        btnGuncelle.setBackground(Color.LIGHT_GRAY);
        btnGuncelle.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnGuncelle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {  // ILAN GUNCELLE BUTONU ACTION PERFORMED
            	String musteri_ad = Musteri.kullaniciAdi;
        		String il = txtIl.getText();
        		String ilce = txtIlce.getText();
        		int m2 =Integer.parseInt(txtM2.getText());
        		String oda_sayisi = txtOdaSayisi.getText();
        		int balkon = Integer.parseInt(txtBalkon.getText());
        		int fiyat = Integer.parseInt(txtFiyat.getText());
                int selectedrow = ilanlarim_tablosu.getSelectedRow();

         
                if (selectedrow == -1) {
                    if (model.getRowCount() == 0) {
                        lblMsj.setText("İlanlar tablosu Şu anda boş.");
                    } else {
                        lblMsj.setText("Lütfen güncellenecek bir ilan seçin.");
                    }
                } else {
                	int id =(int)model.getValueAt(selectedrow, 0);
                	islemler.ilanlarimiGuncelle(id,Musteri.kullaniciAdi,il,ilce,m2,oda_sayisi,balkon,fiyat);
                	islemler.tumilanlarimiGuncelle(id, Musteri.kullaniciAdi,il,ilce,m2,oda_sayisi,balkon,fiyat);
                	musterikonutGoruntule();
            		lblMsj.setText("İlan Başarıyla Güncellendi.");

                	
                }
            }
        });

        btnSil = new JButton("\u0130lan Sil");
        btnSil.setBackground(Color.LIGHT_GRAY);
        btnSil.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnSil.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // ILAN SIL BUTONU ACTION PERFORMED
        	    lblMsj.setText("");
        		int selectedrow = ilanlarim_tablosu.getSelectedRow();
        		if (selectedrow == -1) {
                    if (model.getRowCount() == 0) {
                        lblMsj.setText("İlanlar tablosu şu anda boş.");
                    } else {
                        lblMsj.setText("Lütfen silinecek bir ilan seçin.");
                    }
                } else {
                	int id =(int)model.getValueAt(selectedrow, 0);
                	islemler.ilanlarimiSil(id);
                	islemler.tumilanlarimiSil(id);
                	musterikonutGoruntule();
            		lblMsj.setText("İlan Başarıyla Silindi.");

                	
                }
        		
        		
        		
        	}
        });




        // GENEL LAYOUT
    
        GroupLayout layout = new GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(25)
        					.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        						.addGroup(layout.createSequentialGroup()
        							.addGroup(layout.createParallelGroup(Alignment.LEADING)
        								.addGroup(layout.createSequentialGroup()
        									.addComponent(lblFiyat, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
        									.addPreferredGap(ComponentPlacement.RELATED))
        								.addGroup(layout.createParallelGroup(Alignment.LEADING)
        									.addGroup(layout.createSequentialGroup()
        										.addComponent(lblIl)
        										.addPreferredGap(ComponentPlacement.RELATED))
        									.addGroup(layout.createParallelGroup(Alignment.LEADING)
        										.addGroup(layout.createSequentialGroup()
        											.addComponent(lblM2)
        											.addPreferredGap(ComponentPlacement.RELATED))
        										.addGroup(layout.createSequentialGroup()
        											.addGroup(layout.createParallelGroup(Alignment.LEADING)
        												.addComponent(lblOdaSayisi, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
        												.addComponent(lblBalkon, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE))
        											.addPreferredGap(ComponentPlacement.RELATED))
        										.addGroup(layout.createSequentialGroup()
        											.addComponent(lblIlce)
        											.addGap(31)))))
        							.addGroup(layout.createParallelGroup(Alignment.LEADING)
        								.addGroup(layout.createSequentialGroup()
        									.addGroup(layout.createParallelGroup(Alignment.LEADING)
        										.addComponent(txtIlce, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        										.addComponent(txtM2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        										.addComponent(txtIl, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        										.addComponent(txtOdaSayisi, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        										.addComponent(txtBalkon, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        									.addGap(383)
        									.addGroup(layout.createParallelGroup(Alignment.LEADING)
        										.addComponent(btnGuncelle, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        										.addComponent(btnSil, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        										.addComponent(btnIlanEkle, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        										.addComponent(btnGeri, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE))
        									.addGap(106))
        								.addGroup(layout.createSequentialGroup()
        									.addComponent(txtFiyat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        									.addContainerGap())))
        						.addGroup(layout.createSequentialGroup()
        							.addComponent(lblMsj, GroupLayout.PREFERRED_SIZE, 476, GroupLayout.PREFERRED_SIZE)
        							.addGap(68)
        							.addComponent(lblIlanSayi, GroupLayout.PREFERRED_SIZE, 185, GroupLayout.PREFERRED_SIZE)
        							.addGap(106))))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 850, Short.MAX_VALUE)
        					.addContainerGap())))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(43)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(btnIlanEkle)
        					.addGap(20))
        				.addGroup(layout.createSequentialGroup()
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblIl, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtIl, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.UNRELATED)))
        			.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(btnGuncelle)
        				.addComponent(txtIlce, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblIlce, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(18)
        					.addComponent(btnSil)
        					.addGap(18)
        					.addComponent(btnGeri))
        				.addGroup(layout.createSequentialGroup()
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblM2, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtM2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(txtOdaSayisi, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        						.addComponent(lblOdaSayisi, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblBalkon, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtBalkon, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(lblFiyat, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
        						.addComponent(txtFiyat, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))))
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(12)
        					.addComponent(lblIlanSayi))
        				.addGroup(layout.createSequentialGroup()
        					.addGap(26)
        					.addComponent(lblMsj, GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 303, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        );
        getContentPane().setLayout(layout);

        pack();
    }

    public void musterikonutGoruntule() { // SADECE BELIRLI MUSTERILERIN ILANLARINI GETIRMEK ICIN OLUSTURULAN FONKSIYON VE ARRAYLIST
        
        model.setRowCount(0);
        
        ArrayList<SelectKonut> emlak = new ArrayList<SelectKonut>();
        
        islemler.musteriIlanSayisiniGetir(musteri.getKullaniciAdi());
        
        lblIlanSayi.setText("Toplam İlan Sayıs: "+islemler.musteriIlanSayisiniGetir(musteri.getKullaniciAdi()));
        emlak = islemler.ilanlarimiGetir(/*musteri.getKullaniciAdi()*/);
       
        if (emlak != null ) {
            
            for (SelectKonut konut : emlak) {
            	
                Object[] eklenecek = {konut.getId(),konut.getMusteri_ad(),konut.getIl(),konut.getIlce(),konut.getM2(),konut.getOda_sayisi(),konut.getBalkon(),konut.getFiyat()};
                //konut.getId(),konut.getIl(),konut.getIlce(),konut.getM2(),konut.getOda_sayisi(),konut.getBalkon(),konut.getFiyat()
                model.addRow(eklenecek);
                
                
                
            }
            
        }
        
        
    }
    
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OtomobilIlanlarimEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            	KonutIlanlarimEkrani dialog = new KonutIlanlarimEkrani(new JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    private javax.swing.JTable ilanlarim_tablosu;
    private javax.swing.JScrollPane jScrollPane1;
    private JTextField txtIl;
    private JTextField txtIlce;
    private JTextField txtM2;
    private JTextField txtOdaSayisi;
    private JTextField txtBalkon;
    private JTextField txtFiyat;
    private JButton btnGuncelle;
    private JButton btnSil;
    private JLabel lblIlanSayi;
}

