import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;


public class OtomobilEkrani extends javax.swing.JDialog {
    DefaultTableModel model;
    VasitaMusteriIslemleri islemler =  new VasitaMusteriIslemleri();
    Musteri musteri = new Musteri();
    
    
   
    
    public OtomobilEkrani(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        getContentPane().setBackground(Color.WHITE);
        initComponents();
        model = (DefaultTableModel) otomobil_tablosu.getModel();
        otomobilGoruntule();
        
    }

    

	


    private void initComponents() {  // OTOMOBIL ILANLARI TABLOSU

        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane1.setViewportBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE));
        otomobil_tablosu = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

       otomobil_tablosu.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "marka", "model", "yil", "paket","km","fiyat"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false,false,false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
       
        jScrollPane1.setViewportView(otomobil_tablosu);
        if (otomobil_tablosu.getColumnModel().getColumnCount() > 0) {
        	otomobil_tablosu.getColumnModel().getColumn(0).setResizable(false);
        	otomobil_tablosu.getColumnModel().getColumn(1).setResizable(false);
        	otomobil_tablosu.getColumnModel().getColumn(2).setResizable(false);
        	otomobil_tablosu.getColumnModel().getColumn(3).setResizable(false);
        	otomobil_tablosu.getColumnModel().getColumn(4).setResizable(false);
        	otomobil_tablosu.getColumnModel().getColumn(5).setResizable(false);
        	otomobil_tablosu.getColumnModel().getColumn(6).setResizable(false);
        }
        
        JButton btnIlanlarim = new JButton("\u0130lanlar\u0131m");
        btnIlanlarim.setBackground(Color.LIGHT_GRAY);
        btnIlanlarim.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnIlanlarim.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // ILANLARIM BUTONU ACTION PERFORMED
        		OtomobilIlanlarimEkrani ilanlar = new OtomobilIlanlarimEkrani(new JFrame(), true);
				setVisible(false);
				ilanlar.setVisible(true);

        	}
        });
      
        arama_cubugu = new JTextField();
        arama_cubugu.setFont(new Font("Tahoma", Font.BOLD, 10));
        arama_cubugu.setForeground(new Color(128, 128, 128));
        arama_cubugu.setHorizontalAlignment(SwingConstants.LEFT);
        arama_cubugu.setText("Ara");
        arama_cubugu.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyReleased(KeyEvent e) {
        		String ara =  arama_cubugu.getText();
        		dinamikAra(ara);
        		
        	}
        });
        arama_cubugu.setColumns(10);
        
        separator = new JSeparator();
        
        lblIlanSayi = new JLabel("");
        lblIlanSayi.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        
        JButton btnGeri = new JButton("Geri");
        btnGeri.setBackground(Color.LIGHT_GRAY);
        btnGeri.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnGeri.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {   // GERI BUTONU ACTION PERFORMED
        		EmlakVasitaEkrani emlakvasita = new EmlakVasitaEkrani(musteri);
        		setVisible(false);
        		emlakvasita.setVisible(true);
        		
        	}
        });
        
        JButton btnCikis = new JButton("\u00C7\u0131k\u0131\u015F");
        btnCikis.setBackground(Color.LIGHT_GRAY);
        btnCikis.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnCikis.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {   // CIKIS BUTONU ACTION PERFORMED
        		GirisEkrani giris = new GirisEkrani();
        		setVisible(false);
        		giris.setVisible(true);
        		
        	}
        });




        // OTOMOBIL EKRANI GENEL LAYOUT KISMI

        GroupLayout layout = new GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addComponent(separator, GroupLayout.DEFAULT_SIZE, 758, Short.MAX_VALUE)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(arama_cubugu, GroupLayout.DEFAULT_SIZE, 738, Short.MAX_VALUE)
        			.addContainerGap())
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(btnIlanlarim, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnGeri, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnCikis, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(378, Short.MAX_VALUE))
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 748, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(lblIlanSayi, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(562, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(arama_cubugu, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(separator, GroupLayout.PREFERRED_SIZE, 2, GroupLayout.PREFERRED_SIZE)
        			.addGap(50)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(btnIlanlarim, GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
        				.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        					.addComponent(btnGeri, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
        					.addComponent(btnCikis, GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)))
        			.addGap(50)
        			.addComponent(lblIlanSayi, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)
        			.addGap(40)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 291, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        );
        getContentPane().setLayout(layout);

        pack();
    }

    public void otomobilGoruntule() { // TUM ARABALARI GETIRMEK ICIN OLUSTURULAN FONKSIYON VE ARRAYLIST
        
        model.setRowCount(0);
        
        ArrayList<Otomobil> otomobil = new ArrayList<Otomobil>();
        
        lblIlanSayi.setText("Toplam İlan Sayısı: "+islemler.toplamIlanSayisiniGetir());
        otomobil = islemler.tumIlanlarimiGetir();
        
        if (otomobil != null ) {
            
            for (Otomobil car : otomobil) {
                Object[] eklenecek = {car.getId(),car.getMarka(),car.getModel(),car.getYil(),car.getPaket(),car.getKm(),car.getFiyat()};
                
                model.addRow(eklenecek);
                
                
                
            }
            
        }
        
        
    }
    public void dinamikAra(String ara) {  // DINAMIK ARAMA
    	TableRowSorter<DefaultTableModel>tr = new TableRowSorter<DefaultTableModel>(model);
    	otomobil_tablosu.setRowSorter(tr);
    	tr.setRowFilter(RowFilter.regexFilter(ara));
    }
    
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OtomobilEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OtomobilEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OtomobilEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OtomobilEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                OtomobilEkrani dialog = new OtomobilEkrani(new JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    private javax.swing.JTable otomobil_tablosu;
    private javax.swing.JScrollPane jScrollPane1;
    private JTextField arama_cubugu;
    private JSeparator separator;
    private JLabel lblIlanSayi;
}

