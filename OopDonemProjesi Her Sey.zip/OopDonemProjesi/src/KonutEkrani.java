import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;


public class KonutEkrani extends javax.swing.JDialog {
    DefaultTableModel model;

    // KONUT ILANLARINA OZEL VERITABANI ILE BAGLANTI KURAN EmlakMusterıIslemlerı SINIFINDAN NESNE TURETILDI
    EmlakMusteriIslemleri islemler =  new EmlakMusteriIslemleri();
    Musteri musteri = new Musteri();
    
    
   
    
    public KonutEkrani(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        getContentPane().setBackground(Color.WHITE);
        initComponents();
        model = (DefaultTableModel) konut_tablosu.getModel();
        konutGoruntule();
        
    }

    
    private void initComponents() {  //  KONUT TABLOSU

        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane1.setViewportBorder(new SoftBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE));
        konut_tablosu = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

       konut_tablosu.setModel(new DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "il", "ilce", "m2", "oda sayisi","balkon","fiyat"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false,false,false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });


        jScrollPane1.setViewportView(konut_tablosu);
        if (konut_tablosu.getColumnModel().getColumnCount() > 0) {
        	konut_tablosu.getColumnModel().getColumn(0).setResizable(false);
        	konut_tablosu.getColumnModel().getColumn(1).setResizable(false);
        	konut_tablosu.getColumnModel().getColumn(2).setResizable(false);
        	konut_tablosu.getColumnModel().getColumn(3).setResizable(false);
        	konut_tablosu.getColumnModel().getColumn(4).setResizable(false);
        	konut_tablosu.getColumnModel().getColumn(5).setResizable(false);
        	konut_tablosu.getColumnModel().getColumn(6).setResizable(false);
        }
        
        JButton btnIlanlarim = new JButton("\u0130lanlar\u0131m");
        btnIlanlarim.setBackground(Color.LIGHT_GRAY);
        btnIlanlarim.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnIlanlarim.addActionListener(new ActionListener() {  // ILANLARIM BUTONU ACTION PERFORMED
        	public void actionPerformed(ActionEvent e) {
        		KonutIlanlarimEkrani ilanlar = new KonutIlanlarimEkrani(new JFrame(), true);
				setVisible(false);
				ilanlar.setVisible(true);
				
        		
        	}
        });
      
        arama_cubugu = new JTextField();
        arama_cubugu.setFont(new Font("Tahoma", Font.BOLD, 10));
        arama_cubugu.setForeground(new Color(128, 128, 128));
        arama_cubugu.setHorizontalAlignment(SwingConstants.LEFT);
        arama_cubugu.setText("Ara");
        arama_cubugu.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyReleased(KeyEvent e) {
        		String ara =  arama_cubugu.getText();
        		dinamikAra(ara);
        		
        	}
        });
        arama_cubugu.setColumns(10);
        
        separator = new JSeparator();
        
        lblIlanSayi = new JLabel("");
        lblIlanSayi.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
        
        JButton btnGeri = new JButton("Geri");
        btnGeri.setBackground(Color.LIGHT_GRAY);
        btnGeri.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnGeri.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // GERI BUTONU ACTION PERFORMED
        		EmlakVasitaEkrani emlakvasita = new EmlakVasitaEkrani(musteri);
        		setVisible(false);
        		emlakvasita.setVisible(true);
        		
        	}
        });
        
        JButton btnCikis = new JButton("\u00C7\u0131k\u0131\u015F");
        btnCikis.setBackground(Color.LIGHT_GRAY);
        btnCikis.setFont(new Font("Tahoma", Font.BOLD, 14));
        btnCikis.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {  // CIKIS BUTONU ACTION PERFORMED
        		GirisEkrani giris = new GirisEkrani();
        		setVisible(false);
        		giris.setVisible(true);
        		
        	}
        });



        //  KONUT EKRANI GENLE LAYOUT KISMI

        GroupLayout layout = new GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addComponent(separator, GroupLayout.DEFAULT_SIZE, 771, Short.MAX_VALUE)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(arama_cubugu, GroupLayout.DEFAULT_SIZE, 751, Short.MAX_VALUE)
        			.addContainerGap())
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(btnIlanlarim, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnGeri, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE)
        			.addGap(18)
        			.addComponent(btnCikis, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(391, Short.MAX_VALUE))
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 751, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(lblIlanSayi, GroupLayout.PREFERRED_SIZE, 179, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(582, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(arama_cubugu, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(separator, GroupLayout.PREFERRED_SIZE, 2, GroupLayout.PREFERRED_SIZE)
        			.addGap(50)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(btnIlanlarim, GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
        				.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        					.addComponent(btnGeri, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
        					.addComponent(btnCikis, GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)))
        			.addGap(50)
        			.addComponent(lblIlanSayi, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)
        			.addGap(51)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 301, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        );
        getContentPane().setLayout(layout);

        pack();
    }

    public void konutGoruntule() { 
        
        model.setRowCount(0);
        
        ArrayList<Konut> emlak = new ArrayList<Konut>();  // MUSTERILERIN KONUTLARINI GETIRMEK ICIN OLUSTURULAN ARRAYLIST
        
        lblIlanSayi.setText("Toplam İlan Sayısı : "+islemler.toplamIlanSayisiniGetir());
        emlak = islemler.tumEmlakIlanlarimiGetir();
        
        if (emlak != null ) {
            
            for (Konut konut : emlak) {
                Object[] eklenecek = {konut.getId(),konut.getIl(),konut.getIlce(),konut.getM2(),konut.getOda_sayisi(),konut.getBalkon(),konut.getFiyat()};
                
                model.addRow(eklenecek);
            }
            
        }

    }

    public void dinamikAra(String ara) {  // DINAMIK ARAMA KISMI
    	TableRowSorter<DefaultTableModel>tr = new TableRowSorter<DefaultTableModel>(model);
    	konut_tablosu.setRowSorter(tr);
    	tr.setRowFilter(RowFilter.regexFilter(ara));
    }
    
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KonutEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KonutEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KonutEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KonutEkrani.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                KonutEkrani dialog = new KonutEkrani(new JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    private javax.swing.JTable konut_tablosu;
    private javax.swing.JScrollPane jScrollPane1;
    private JTextField arama_cubugu;
    private JSeparator separator;
    private JLabel lblIlanSayi;
}


