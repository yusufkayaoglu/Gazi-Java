import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class Database {   // DATABSE BAGLANTILARI ICIN OLUSTURULAN SINIF
	public static final String kullanıcı_adı ="root";
	public static final String parola ="sifre";
	public static final String db_ismi ="database2";
	public static final String host ="localhost";
	public static final int port = 3306;
	public static  Statement statement = null;
	public static Connection con  = null;
	public static PreparedStatement preparedStatement = null;

}

