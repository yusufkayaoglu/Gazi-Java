import java.util.ArrayList;

public interface IMusteriIslemleri {   // BAZI ORTAK MUSTERI ISLEMLERI ILE ILGILI FONKSIYONLARI TUTAN INTERFCE

	public void ilanlarimiGuncelle(int prm1,String prm2, String prm3, String prm4, int prm5, String prm6, int prm7, int prm8);
	public void tumilanlarimiGuncelle(int prm1_yeni,String prm2_yeni, String prm3_yeni, String prm4_yeni, int prm5_yeni, String prm6_yeni, int prm7_yeni, int prm8_yeni);
	 public void ilanlarimiSil(int id);
	 public void tumilanlarimiSil(int id);
	 public void tumilanEkle(int prm1,String prm2,String prm3,int prm4,String prm5,int prm6,int prm7);
	 public void ilanlarimaEkle(String prm2, String prm3, String prm4, int prm5, String prm6, int prm7, int prm8);
	 public String musteriIlanSayisiniGetir(String musteri_ad);
	 public String toplamIlanSayisiniGetir();
	 
	  
}
