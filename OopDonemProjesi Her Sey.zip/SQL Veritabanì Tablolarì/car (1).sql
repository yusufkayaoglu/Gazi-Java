-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 09 Oca 2024, 14:20:12
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `database2`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `car`
--

CREATE TABLE `car` (
  `id` int(11) NOT NULL,
  `marka` text NOT NULL,
  `model` text NOT NULL,
  `yil` int(11) NOT NULL,
  `paket` text NOT NULL,
  `km` int(11) NOT NULL,
  `fiyat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `car`
--

INSERT INTO `car` (`id`, `marka`, `model`, `yil`, `paket`, `km`, `fiyat`) VALUES
(1, 'Audi', 'A5', 2020, 'Quattro S Line', 49000, 3080000),
(2, 'Audi', 'A8', 2013, 'Quattro R Tronic', 6000, 24500000),
(3, 'Volkswagen', 'Arteon', 2017, 'R Line', 220000, 1695000),
(7, 'Dacia', 'Duster', 2012, 'Ambiance', 350000, 475000),
(8, 'Volkswagen', 'Passat', 2018, 'R Line', 185000, 2750000),
(9, 'Tofaş', 'Doğan', 1998, 'SLX ie', 42000, 425000),
(10, 'Volkswagen', 'Bora', 2000, '2.0', 245000, 405000),
(11, 'Mercedes', 'E200', 1996, 'Classic', 334000, 435000),
(12, 'Audi', 'R8', 2013, 'Quattro', 21000, 11000000),
(13, 'Skoda', 'Superb', 2019, 'Prestige', 179000, 1400000),
(15, 'Toyota', 'Corolla', 2017, 'Advance', 95000, 875000),
(16, 'Fiat', 'Linea', 2012, 'Active Plus', 142000, 385000),
(17, 'Ford', 'Focus', 2006, 'Ghia', 225000, 425000),
(18, 'Renault', 'Symbol', 2013, 'Joy', 130000, 400000),
(19, 'Peugeot', '3008', 2022, 'GT Line', 12000, 1600000),
(20, 'Mercedes', 'Vito', 2023, '119 Bluetec', 0, 4040000),
(21, 'bmw', '530i', 2015, 'm sport', 75000, 2250000),
(23, 'Volkswagen', 'Arteon', 2024, 'R Line', 121, 2500000),
(24, 'Toyota', 'Auris', 2013, 'Active Skypack', 92000, 795000),
(25, 'Volvo', 'S90', 2017, 'Inscription', 175000, 2140000),
(26, 'Cherry', 'Tigo 7 Pro', 2023, 'Excellant', 400, 1320000);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
