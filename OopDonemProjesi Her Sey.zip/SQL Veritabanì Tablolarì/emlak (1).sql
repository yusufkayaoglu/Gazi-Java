-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 09 Oca 2024, 14:20:26
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `database2`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `emlak`
--

CREATE TABLE `emlak` (
  `id` int(11) NOT NULL,
  `il` text NOT NULL,
  `ilce` text NOT NULL,
  `m2` int(11) NOT NULL,
  `oda_sayisi` text NOT NULL,
  `balkon` int(11) NOT NULL,
  `fiyat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `emlak`
--

INSERT INTO `emlak` (`id`, `il`, `ilce`, `m2`, `oda_sayisi`, `balkon`, `fiyat`) VALUES
(1, 'İstanbul', 'Üsküdar', 112, '3', 0, 2000000),
(2, 'Ankara', 'Mamak', 125, '4', 1, 1600000),
(3, 'Ankara', 'Gölbaşı', 125, '5', 1, 4200000),
(4, 'İstanbul', 'Esenyurt', 85, '2', 1, 1330000),
(5, 'Diyarbakır', 'Bağlar', 91, '4', 2, 1600000),
(6, 'Ankara', 'Gölbaşı', 110, '4', 2, 1500000),
(7, 'Adana', 'Çukurova', 275, '5', 2, 4400000),
(8, 'İzmir', 'Balçova', 150, '4', 2, 3770000),
(9, 'Van', 'İpekyolu', 155, '3', 1, 2035000),
(10, 'Kayseri', 'Talas', 135, '4', 2, 3230000),
(11, 'Bursa', 'Yıldırım', 100, '3', 1, 900000),
(12, 'Bursa', 'Yıldırım', 142, '4', 1, 3350000),
(13, 'Bursa', 'Nilüfer', 87, '3', 1, 4250000),
(14, 'Bursa', 'Nilüfer', 90, '3', 2, 2075000),
(15, 'Bursa', 'Bilecik', 120, '3', 1, 2550000),
(16, 'Diyarbakır', 'Kayapınar', 130, '4', 1, 4000000),
(17, 'Diyarbakır', 'Yenişehir', 90, '3', 0, 1200000),
(18, 'Diyarbakır', 'Ergani', 95, '3', 1, 1600000),
(19, 'Diyarbakır', 'Sur', 105, '4', 2, 2750000),
(20, 'İstanbul', 'Üsküdar', 90, '3', 1, 3050000),
(21, 'Sivas', 'Gökçebostan', 150, '4', 1, 2150000),
(22, 'İstanbul', 'Küçükçekmece', 112, '3', 1, 2600000),
(23, 'Muğla', 'Bodrum', 230, '6', 3, 12000000),
(25, 'Ankara', 'Çankaya', 485, '6', 3, 6896932),
(26, 'Ankara', 'Gölbaşı', 108, '3', 2, 2400000),
(28, 'İstanbul', 'Kadıköy', 117, '3', 1, 1600000);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `emlak`
--
ALTER TABLE `emlak`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `emlak`
--
ALTER TABLE `emlak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
